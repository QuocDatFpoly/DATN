package J6D4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class J6D4Application {

	public static void main(String[] args) {
		SpringApplication.run(J6D4Application.class, args);
	}

}
