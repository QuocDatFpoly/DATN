package J6D4.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
	String username;
	String pass;
	Boolean role;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Boolean getRole() {
		return role;
	}
	public void setRole(Boolean role) {
		this.role = role;
	}
	public Student(String username, String pass, Boolean role) {
		super();
		this.username = username;
		this.pass = pass;
		this.role = role;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
}





