package J6D4.bean;

import java.util.HashMap;

public class StudentMap extends HashMap<String,Student> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1932271225110679614L;

}
