package com.quocdat.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.quocdat.entity.Student;

 

public interface StudentDAO extends JpaRepository<Student, Integer> {
	@Query(value="SELECT * FROM Students WHERE name LIKE ?1 or mssv LIKE ?1 or major LIKE ?1 ",nativeQuery = true)
	List<Student> findByKeyword(String keyword);
}
