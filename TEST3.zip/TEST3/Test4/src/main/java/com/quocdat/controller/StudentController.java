package com.quocdat.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.quocdat.dao.StudentDAO;
import com.quocdat.entity.Student;

@Controller
public class StudentController {
	@Autowired
	StudentDAO dao;
	
	@RequestMapping("/student/index")
	public String index(Model model) {
		List<Student> items = dao.findAll();
		model.addAttribute("items", items);
		return "student2";
	}
	
	@RequestMapping("/student/new")
	public String news(Model model) {
		model.addAttribute("item", new Student());
		return "form";
	}
	
	@RequestMapping("/student/create")
	public String create(Student item) {
		dao.save(item);
		return "redirect:/student/index";
	}
	
	@RequestMapping("/student/edit/{mssv}")
	public String edit(Model model, @PathVariable("mssv") Integer id) {
		Student item = dao.findById(id).get();
		model.addAttribute("item", item);
		return "form";
	}
	
	@RequestMapping("/student/delete/{id}")
	public String create(@PathVariable("id") Integer id) {
		dao.deleteById(id);
		return "redirect:/student/index";
	}
	
	@RequestMapping("/student/search")
	public String search(Model model, @RequestParam("search") String kw) {
		List<Student> items = dao.findByKeyword("%" + kw + "%");
		model.addAttribute("items", items);
		return "student2";
	}
	
	@RequestMapping("/student/update")
	public String update(Student item) {
		dao.save(item);
		return "redirect:/student/index";
	}
}
