package com.quocdat.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity 
@Table(name = "Students")
public class Student {
	@Id 
	Integer mssv;
	String name;
	String mark;
	String major;

	
	public Integer getMssv() {
		return mssv;
	}
	public Integer getmssv() {
		return mssv;
	}
	public void setMssv(Integer mssv) {
		this.mssv = mssv;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public Student(Integer mssv, String name, String mark, String major) {
		super();
		this.mssv = mssv;
		this.name = name;
		this.mark = mark;
		this.major = major;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
